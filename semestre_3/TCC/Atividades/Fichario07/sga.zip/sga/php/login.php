<?php
session_start(); // 🔥 ESSENCIAL
include 'conexao.php';

$email = $_POST['email'];
$senha = $_POST['senha'];

$sql = "SELECT * FROM usuarios WHERE email='$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();

    if (password_verify($senha, $user['senha'])) {

        $_SESSION['usuario_id'] = $user['id']; // 🔥 GUARDA USUÁRIO

        echo "login_ok";
        exit;

    } else {
        echo "senha_incorreta";
        exit;
    }

} else {
    echo "usuario_nao_encontrado";
    exit;
}
?>
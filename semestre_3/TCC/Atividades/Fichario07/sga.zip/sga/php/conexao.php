
<?php
/*
$host = "localhost";
$user = "root";
$pass = "";
$db = "sga";
$port = 3307; // 👈 ESSA LINHA É A SOLUÇÃO

$conn = new mysqli($host, $user, $pass, $db, $port);

if ($conn->connect_error) {
    die("Erro: " . $conn->connect_error);
    }
    */
?>
<?php
include 'conexao.php';

$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);
$endereco = $_POST['endereco'];

$sql = "INSERT INTO usuarios (nome, email, senha, endereco)
        VALUES ('$nome', '$email', '$senha', '$endereco')";

if ($conn->query($sql) === TRUE) {
    echo "Cadastro realizado!";
} else {
    echo "Erro: " . $conn->error;
}
?>
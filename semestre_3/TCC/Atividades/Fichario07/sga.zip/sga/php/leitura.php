<?php
session_start(); // 🔥 ESSENCIAL
include 'conexao.php';

if (!isset($_SESSION['usuario_id'])) {
    echo "Erro: usuário não autenticado";
    exit;
}

$usuario_id = $_SESSION['usuario_id'];

date_default_timezone_set('America/Sao_Paulo');

$data = $_POST['dataLeitura'];
$valor = $_POST['valorLeitura'];

$hoje = date("Y-m-d");

// 🔥 BLOQUEAR DATA FUTURA
if ($data > $hoje) {
    echo "Erro: Não é permitido registrar datas futuras.";
    exit;
}

// 🔥 VALIDAR VALOR
if (!is_numeric($valor) || $valor < 0) {
    echo "Erro: Valor inválido.";
    exit;
}

// 🔥 EVITAR DUPLICIDADE POR USUÁRIO
$sqlCheck = "SELECT * FROM leituras 
             WHERE dataLeitura = '$data' 
             AND usuario_id = '$usuario_id'";

$result = $conn->query($sqlCheck);

if ($result->num_rows > 0) {
    echo "Erro: Já existe uma leitura para essa data.";
    exit;
}

// 🔥 INSERT COM USUÁRIO
$sql = "INSERT INTO leituras (usuario_id, dataLeitura, valorLeitura)
        VALUES ('$usuario_id', '$data', '$valor')";

if ($conn->query($sql) === TRUE) {
    echo "ok";
} else {
    echo "Erro: " . $conn->error;
}
?>
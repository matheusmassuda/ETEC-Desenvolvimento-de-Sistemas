<?php
session_start(); // 🔥 ESSENCIAL
include 'conexao.php';

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(["labels"=>[], "valores"=>[]]);
    exit;
}

$usuario_id = $_SESSION['usuario_id'];

date_default_timezone_set('America/Sao_Paulo');

$diasSemana = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab"];

$labels = [];
$valores = [];

// 🔥 1. PEGA ÚLTIMA DATA DO USUÁRIO
$sqlUltima = "SELECT MAX(dataLeitura) as ultima 
              FROM leituras 
              WHERE usuario_id = '$usuario_id'";

$resultUltima = $conn->query($sqlUltima);
$rowUltima = $resultUltima->fetch_assoc();

$dataBase = $rowUltima['ultima'];

if (!$dataBase) {
    $dataBase = date("Y-m-d");
}

// 🔥 2. BUSCA DADOS DO USUÁRIO
$sql = "SELECT DATE(dataLeitura) as data, valorLeitura 
        FROM leituras 
        WHERE usuario_id = '$usuario_id'";

$result = $conn->query($sql);

$dadosBanco = [];

while ($row = $result->fetch_assoc()) {
    $dadosBanco[$row['data']] = (float)$row['valorLeitura'];
}

// 🔥 3. MONTA OS 7 DIAS
for ($i = 6; $i >= 0; $i--) {

    $data = date("Y-m-d", strtotime($dataBase . " -$i days"));
    $diaSemana = $diasSemana[date('w', strtotime($data))];
    $dataFormatada = date("d/m", strtotime($data));

    $labels[] = [$diaSemana, $dataFormatada];

    if (isset($dadosBanco[$data])) {
        $valores[] = $dadosBanco[$data];
    } else {
        $valores[] = 0;
    }
}

echo json_encode([
    "labels" => $labels,
    "valores" => $valores
]);
?>
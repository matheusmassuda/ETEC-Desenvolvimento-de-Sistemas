function irCadastro() {
  window.location.href = "cadastro.html";
}

function login() {
  const email = document.getElementById("email").value;
  const senha = document.getElementById("senha").value;

  fetch("php/login.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: `email=${email}&senha=${senha}`
  })
  .then(res => res.text())
  .then(data => {
    if (data === "login_ok") {
      localStorage.setItem("usuario", email);
      window.location.href = "leitura.html";
    } else {
      alert("Erro no login");
    }
  });
}

function focarLogin() {
  const input = document.getElementById("email");
  if (input) input.focus();
}

window.addEventListener("hashchange", focarLogin);
window.addEventListener("load", () => {
  if (window.location.hash === "#entrar") focarLogin();
});

/* TOGGLE */
document.querySelectorAll("[aria-controls]").forEach(btn => {
  btn.addEventListener("click", () => {
    const expanded = btn.getAttribute("aria-expanded") === "true";
    const target = document.getElementById(btn.getAttribute("aria-controls"));

    btn.setAttribute("aria-expanded", !expanded);

    if (!expanded) {
      target.classList.add("open");
      target.style.maxHeight = target.scrollHeight + "px";
    } else {
      target.style.maxHeight = "0px";
      target.classList.remove("open");
    }
  });
});
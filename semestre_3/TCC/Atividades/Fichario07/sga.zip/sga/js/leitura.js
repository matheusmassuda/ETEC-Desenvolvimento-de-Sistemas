function salvarLeitura() {
    let inicial = document.getElementById("leituraInicial").value;
    let final = document.getElementById("leituraFinal").value;

    let consumo = final - inicial;

    let dados = new URLSearchParams();
    dados.append("inicial", inicial);
    dados.append("final", final);
    dados.append("consumo", consumo);

    fetch("php/leitura.php", {
        method: "POST",
        body: dados
    })
    .then(res => res.text())
    .then(msg => alert(msg));
}

function irDashboard() {
    window.location.href = "dashboard.html";
}
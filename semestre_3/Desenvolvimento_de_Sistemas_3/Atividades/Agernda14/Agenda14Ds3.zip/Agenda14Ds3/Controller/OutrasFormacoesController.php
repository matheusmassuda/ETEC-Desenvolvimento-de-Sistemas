<?php
require_once '../Model/ConexaoBD.php';
require_once '../Model/OutrasFormacoes.php';

class OutrasFormacoesController
{
    // LISTAR OUTRAS FORMAÇÕES
    public function gerarLista($idUsuario)
    {
        $of = new OutrasFormacoes();
        return $of->listaFormacoes($idUsuario);
    }

    // ADICIONAR OUTRA FORMAÇÃO
    public function adicionar($idUsuario, $curso, $instituicao, $cargaHoraria)
    {
        $of = new OutrasFormacoes();
        $of->setIdUsuario($idUsuario);
        $of->setCurso($curso);
        $of->setInstituicao($instituicao);
        $of->setCargaHoraria($cargaHoraria);

        return $of->inserirBD();
    }

    // EXCLUIR OUTRA FORMAÇÃO
    public function excluir($id)
    {
        $of = new OutrasFormacoes();
        return $of->excluirBD($id);
    }
}
?>

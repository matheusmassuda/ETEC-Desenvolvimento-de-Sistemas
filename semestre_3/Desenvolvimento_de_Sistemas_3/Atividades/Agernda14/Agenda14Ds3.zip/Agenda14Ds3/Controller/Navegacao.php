<?php
// INICIAR SESSÃO SEMPRE NO TOPO
if (!isset($_SESSION)) {
    session_start();
}

// IMPORTA MODELS E CONTROLLERS
require_once '../Model/Usuario.php';
require_once '../Controller/FormacaoAcadController.php';
require_once '../Controller/ExperienciaProfissionalController.php';
require_once '../Controller/OutrasFormacoesController.php';

/*LOGIN*/
if (isset($_POST['btnLogin'])) {

    require_once '../Model/ConexaoBD.php';
    require_once '../Model/Usuario.php';

    $login = $_POST['txtLogin'];
    $senha = $_POST['txtSenha'];

    $conn = (new ConexaoBD())->conectar();

    $sql = "SELECT * FROM usuario WHERE cpf = '$login' AND senha = '$senha'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {

        $row = $result->fetch_object();

        $usuario = new Usuario();
        $usuario->setID($row->idusuario);
        $usuario->setNome($row->nome);
        $usuario->setCPF($row->cpf);
        $usuario->setDataNascimento($row->dataNascimento);
        $usuario->setEmail($row->email);

        $_SESSION['Usuario'] = serialize($usuario);
        $_SESSION['UsuarioID'] = $row->idusuario;

        header("Location: ../View/principal.php");
        exit;

    } else {
        echo "<h2 style='color:red; text-align:center;'>Login ou senha incorretos</h2>";
    }

    $conn->close();
}

/* ATUALIZAR DADOS PESSOAIS*/
if (isset($_POST['btnAtualizar'])) {

    $usuario = new Usuario();
    $usuario->setID($_POST['txtID']);
    $usuario->setNome($_POST['txtNome']);
    $usuario->setCPF($_POST['txtCPF']);
    $usuario->setDataNascimento($_POST['txtData']);
    $usuario->setEmail($_POST['txtEmail']);

    $usuario->atualizarBD();

    $_SESSION['Usuario'] = serialize($usuario);

    header("Location: ../View/principal.php#dPessoais");
    exit;
}

/*FORMAÇÃO ACADÊMICA*/
if (isset($_POST['btnAddFormacao'])) {

    $controller = new FormacaoAcadController();
    $controller->adicionar(
        $_SESSION['UsuarioID'],
        $_POST['txtInicioFA'],
        $_POST['txtFimFA'],
        $_POST['txtDescFA']
    );

    header("Location: ../View/principal.php#formacao");
    exit;
}

if (isset($_POST['btnExcluirFA'])) {

    $controller = new FormacaoAcadController();
    $controller->excluir($_POST['id']);

    header("Location: ../View/principal.php#formacao");
    exit;
}

/* OUTRAS FORMAÇÕES */
if (isset($_POST['btnAddOF'])) {

    $controller = new OutrasFormacoesController();
    $controller->adicionar(
        $_SESSION['UsuarioID'],
        $_POST['txtCursoOF'],
        $_POST['txtInstituicaoOF'],
        $_POST['txtCargaHorariaOF']
    );

    header("Location: ../View/principal.php#oFormacoes");
    exit;
}

if (isset($_POST['btnExcluirOF'])) {

    $controller = new OutrasFormacoesController();
    $controller->excluir($_POST['idOF']);

    header("Location: ../View/principal.php#oFormacoes");
    exit;
}

/* EXPERIÊNCIA PROFISSIONAL*/
if (isset($_POST['btnAddEP'])) {

    $controller = new ExperienciaProfissionalController();
    $controller->adicionar(
        $_SESSION['UsuarioID'],
        $_POST['txtInicioEP'],
        $_POST['txtFimEP'],
        $_POST['txtEmpEP'],
        $_POST['txtDescEP']
    );

    header("Location: ../View/principal.php#eProfissional");
    exit;
}

if (isset($_POST['btnExcluirEP'])) {

    $controller = new ExperienciaProfissionalController();
    $controller->excluir($_POST['idEP']);

    header("Location: ../View/principal.php#eProfissional");
    exit;
}

?>

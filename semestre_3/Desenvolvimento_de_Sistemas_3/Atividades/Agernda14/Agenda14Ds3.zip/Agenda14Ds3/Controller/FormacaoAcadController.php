<?php
require_once '../Model/ConexaoBD.php';
require_once '../Model/FormacaoAcademica.php';

class FormacaoAcadController
{
    // LISTAR FORMAÇÕES
    public function gerarLista($idUsuario)
    {
        $fa = new FormacaoAcademica();
        return $fa->listaFormacoes($idUsuario);
    }

    // ADICIONAR FORMAÇÃO
    public function adicionar($idUsuario, $inicio, $fim, $descricao)
    {
        $fa = new FormacaoAcademica();
        $fa->setIdUsuario($idUsuario);
        $fa->setInicio($inicio);
        $fa->setFim($fim);
        $fa->setDescricao($descricao);

        return $fa->inserirBD();
    }

    // EXCLUIR FORMAÇÃO
    public function excluir($id)
    {
        $fa = new FormacaoAcademica();
        return $fa->excluirBD($id);
    }
}
?>

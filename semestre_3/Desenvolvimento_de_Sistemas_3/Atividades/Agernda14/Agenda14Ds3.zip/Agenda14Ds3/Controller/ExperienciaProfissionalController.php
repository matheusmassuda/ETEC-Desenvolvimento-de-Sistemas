<?php
require_once '../Model/ConexaoBD.php';
require_once '../Model/ExperienciaProfissional.php';

class ExperienciaProfissionalController
{
    // LISTAR EXPERIÊNCIAS
    public function gerarLista($idUsuario)
    {
        $ep = new ExperienciaProfissional();
        return $ep->listaExperiencias($idUsuario);
    }

    // ADICIONAR EXPERIÊNCIA
    public function adicionar($idUsuario, $inicio, $fim, $empresa, $descricao)
    {
        $ep = new ExperienciaProfissional();
        $ep->setIdUsuario($idUsuario);
        $ep->setInicio($inicio);
        $ep->setFim($fim);
        $ep->setEmpresa($empresa);
        $ep->setDescricao($descricao);

        return $ep->inserirBD();
    }

    // EXCLUIR EXPERIÊNCIA
    public function excluir($id)
    {
        $ep = new ExperienciaProfissional();
        return $ep->excluirBD($id);
    }
}
?>

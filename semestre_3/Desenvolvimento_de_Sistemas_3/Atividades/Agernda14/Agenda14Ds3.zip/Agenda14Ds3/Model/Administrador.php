<?php

class Administrador {

    // Atributos da classe administrador
    private $id;
    private $nome;
    private $cpf;
    private $senha;

    // Métodos Getters e Setters

    public function setID($id) { 
        $this->id = $id; 
    }
    public function getID() { 
        return $this->id; 
    }

    public function setNome($nome) { 
        $this->nome = $nome; 
    }
    public function getNome() { 
        return $this->nome; 
    }

    public function setCPF($cpf) { 
        $this->cpf = $cpf; 
    }
    public function getCPF() { 
        return $this->cpf; 
    }

    public function setSenha($senha) { 
        $this->senha = $senha; 
    }
    public function getSenha() { 
        return $this->senha; 
    }

    // Carregamento do Administrador
    public function carregarAdministrador($cpf) {
        require_once 'ConexaoBD.php';

        //Chama a conexão com BANCO DE DADOS
        $con = new ConexaoBD();
        $conn = $con->conectar();

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        //Faz a checagem do administrador por meio do CPF passado na função
        $sql = "SELECT * FROM administrador WHERE cpf = ".$cpf;
        $re = $conn->query($sql);
        $r = $re->fetch_object();

        //Teste se existe perfil do administrador com if else
        if($r != null) {
            $this->id = $r->idadministrador;
            $this->nome = $r->nome;
            $this->cpf = $r->cpf;
            $this->senha = $r->senha;

            $conn->close();
            return true;
        } else {
            $conn->close();
            return false;
        }
    }

    // Método para listar os cadastros
    public function listaCadastrados() {
        require_once 'ConexaoBD.php';
        $con = new ConexaoBD();
        $conn = $con->conectar();

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "SELECT idadministrador, nome, cpf FROM administrador;";
        $re = $conn->query($sql);

        $conn->close();
        return $re;
    }

}

?>

<?php

class OutrasFormacoes
{
    private $id;
    private $idusuario;
    private $curso;
    private $instituicao;
    private $cargaHoraria;

    // GETTERS E SETTERS
    public function getId() { return $this->id; }
    public function setId($id) { $this->id = $id; }

    public function getIdUsuario() { return $this->idusuario; }
    public function setIdUsuario($idusuario) { $this->idusuario = $idusuario; }

    public function getCurso() { return $this->curso; }
    public function setCurso($curso) { $this->curso = $curso; }

    public function getInstituicao() { return $this->instituicao; }
    public function setInstituicao($instituicao) { $this->instituicao = $instituicao; }

    public function getCargaHoraria() { return $this->cargaHoraria; }
    public function setCargaHoraria($cargaHoraria) { $this->cargaHoraria = $cargaHoraria; }

    // INSERIR NO BANCO
    public function inserirBD()
    {
        require_once 'ConexaoBD.php';
        $conn = (new ConexaoBD())->conectar();

        $sql = "INSERT INTO outrasformacoes (idusuario, curso, instituicao, cargaHoraria)
                VALUES ('{$this->idusuario}', '{$this->curso}', '{$this->instituicao}', '{$this->cargaHoraria}')";

        if ($conn->query($sql)) {
            $this->id = $conn->insert_id;
            $conn->close();
            return true;
        }

        $conn->close();
        return false;
    }

    // EXCLUIR DO BANCO
    public function excluirBD($id)
    {
        require_once 'ConexaoBD.php';
        $conn = (new ConexaoBD())->conectar();

        $sql = "DELETE FROM outrasformacoes WHERE idoutrasformacoes = '$id'";

        $ok = $conn->query($sql);
        $conn->close();
        return $ok;
    }

    // LISTAR DO BANCO
    public function listaFormacoes($idusuario)
    {
        require_once 'ConexaoBD.php';
        $conn = (new ConexaoBD())->conectar();

        $sql = "SELECT * FROM outrasformacoes WHERE idusuario = '$idusuario'";
        $result = $conn->query($sql);

        $conn->close();
        return $result;
    }
}
?>


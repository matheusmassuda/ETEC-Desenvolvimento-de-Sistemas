<?php

class FormacaoAcademica
{
    private $id;
    private $idusuario;
    private $inicio;
    private $fim;
    private $descricao;

    public function getId() { return $this->id; }
    public function setId($id) { $this->id = $id; }

    public function getIdUsuario() { return $this->idusuario; }
    public function setIdUsuario($idusuario) { $this->idusuario = $idusuario; }

    public function getInicio() { return $this->inicio; }
    public function setInicio($inicio) { $this->inicio = $inicio; }

    public function getFim() { return $this->fim; }
    public function setFim($fim) { $this->fim = $fim; }

    public function getDescricao() { return $this->descricao; }
    public function setDescricao($descricao) { $this->descricao = $descricao; }

    public function inserirBD()
    {
        require_once 'ConexaoBD.php';
        $conn = (new ConexaoBD())->conectar();

        $sql = "INSERT INTO formacaoacademica (idusuario, inicio, fim, descricao)
                VALUES ('{$this->idusuario}', '{$this->inicio}', '{$this->fim}', '{$this->descricao}')";

        if ($conn->query($sql)) {
            $this->id = $conn->insert_id;
            $conn->close();
            return true;
        }

        $conn->close();
        return false;
    }

    public function excluirBD($id)
    {
        require_once 'ConexaoBD.php';
        $conn = (new ConexaoBD())->conectar();

        $sql = "DELETE FROM formacaoacademica WHERE idformacaoAcademica = '$id'";

        $ok = $conn->query($sql);
        $conn->close();
        return $ok;
    }

    public function listaFormacoes($idusuario)
    {
        require_once 'ConexaoBD.php';
        $conn = (new ConexaoBD())->conectar();

        $sql = "SELECT * FROM formacaoacademica WHERE idusuario = '$idusuario'";
        $result = $conn->query($sql);

        $conn->close();
        return $result;
    }
}
?>

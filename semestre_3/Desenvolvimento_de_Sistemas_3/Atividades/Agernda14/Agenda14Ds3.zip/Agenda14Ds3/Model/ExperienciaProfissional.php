<?php

class ExperienciaProfissional
{
    private $id;
    private $idusuario;
    private $inicio;
    private $fim;
    private $empresa;
    private $descricao;

    // GETTERS E SETTERS
    public function getId() { return $this->id; }
    public function setId($id) { $this->id = $id; }

    public function getIdUsuario() { return $this->idusuario; }
    public function setIdUsuario($idusuario) { $this->idusuario = $idusuario; }

    public function getInicio() { return $this->inicio; }
    public function setInicio($inicio) { $this->inicio = $inicio; }

    public function getFim() { return $this->fim; }
    public function setFim($fim) { $this->fim = $fim; }

    public function getEmpresa() { return $this->empresa; }
    public function setEmpresa($empresa) { $this->empresa = $empresa; }

    public function getDescricao() { return $this->descricao; }
    public function setDescricao($descricao) { $this->descricao = $descricao; }

    // INSERIR NO BANCO
    public function inserirBD()
    {
        require_once 'ConexaoBD.php';
        $conn = (new ConexaoBD())->conectar();

        $sql = "INSERT INTO experienciaprofissional (idusuario, inicio, fim, empresa, descricao)
                VALUES ('{$this->idusuario}', '{$this->inicio}', '{$this->fim}', '{$this->empresa}', '{$this->descricao}')";

        if ($conn->query($sql)) {
            $this->id = $conn->insert_id;
            $conn->close();
            return true;
        }

        $conn->close();
        return false;
    }

    // EXCLUIR DO BANCO
    public function excluirBD($id)
    {
        require_once 'ConexaoBD.php';
        $conn = (new ConexaoBD())->conectar();

        $sql = "DELETE FROM experienciaprofissional WHERE idexperienciaprofissional = '$id'";

        $ok = $conn->query($sql);
        $conn->close();
        return $ok;
    }

    // LISTAR EXPERIÊNCIAS
    public function listaExperiencias($idusuario)
    {
        require_once 'ConexaoBD.php';
        $conn = (new ConexaoBD())->conectar();

        $sql = "SELECT * FROM experienciaprofissional WHERE idusuario = '$idusuario'";
        $result = $conn->query($sql);

        $conn->close();
        return $result;
    }
}
?>

<?php

class ConexaoBD {

    private $serverName = "localhost";   // servidor
    private $userName   = "root";        // usuário
    private $password   = "";            // senha (vazia no XAMPP)
    private $dbName     = "projeto_final"; // nome do banco

    public function conectar() {

        $conexao = new mysqli(
            $this->serverName,
            $this->userName,
            $this->password,
            $this->dbName
        );

        if ($conexao->connect_error) {
            die("Falha na conexão: " . $conexao->connect_error);
        }

        return $conexao;
    }
}

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Enlatados Juarez</title>

    <style>
        .w3-sidebar {
            width: 120px;
        }
        body, h1, h2, h3, h4, h5, h6 {
            font-family: "Montserrat", sans-serif;
        }
    </style>
</head>

<body class="w3-light-grey">

    <!------------------------------------------------- MENU NAVEGAÇÃO -->
    <nav class="w3-sidebar w3-bar-block w3-center w3-blue">
        <a href="#home" class="w3-bar-item w3-button w3-hover-light-grey w3-hover-text-cyan w3-text-light-grey">
            <i class="fa fa-home w3-xxlarge"></i>
            <p>HOME</p>
        </a>

        <a href="#dPessoais" class="w3-bar-item w3-button w3-hover-light-grey w3-hover-text-cyan w3-text-light-grey">
            <i class="fa fa-address-book-o w3-xxlarge"></i>
            <p>Dados Pessoais</p>
        </a>

        <a href="#formacao" class="w3-bar-item w3-button w3-hover-light-grey w3-hover-text-cyan w3-text-light-grey">
            <i class="fa fa-mortar-board w3-xxlarge"></i>
            <p>Formação</p>
        </a>

        <a href="#eProfissional" class="w3-bar-item w3-button w3-hover-light-grey w3-hover-text-cyan w3-text-light-grey">
            <i class="fa fa-briefcase w3-xxlarge"></i>
            <p>Experiência</p>
        </a>

        <a href="#oFormacoes" class="w3-bar-item w3-button w3-hover-light-grey w3-hover-text-cyan w3-text-light-grey">
            <i class="fa fa-book w3-xxlarge"></i>
            <p>Outras Formações</p>
        </a>
    </nav>



    <!-- ------------------------------------CABEÇALHO (COM IMAGEM) -->
    <div class="w3-padding-large" id="main" style="margin-left:120px;">

        <!-- HOME -->
        <header class="w3-container w3-padding-32 w3-center" id="home">
            <h1>
                <img src="../img/Enlatados.jpg" alt="Logo" class="w3-image" width="50%">
            </h1>
            <a class="w3-text-cyan" href="https://unsplash.com/pt-br/fotografias/uma-pilha-de-latas-de-comida-sentadas-uma-ao-lado-da-outra-514ttExZr1U">Designed by Jacob McGowin / Unsplash</a>
            <h1 class="w3-text-cyan">SISTEMA DE CURRICULOS</h1>
        </header>



        <!-- --------------------------------------- DADOS PESSOAIS -->
        <div class="w3-padding-128 w3-content w3-text-grey" id="dPessoais">
            <h2 class="w3-text-cyan">Dados Pessoais</h2>
        </div>

        <form action="" method="post" class="w3-row w3-light-grey w3-text-blue w3-margin" style="width:70%;">
            <input class="w3-input w3-border w3-round-large" type="hidden" name="txtID" value="">

            <div class="w3-row w3-section">
                <div class="w3-col" style="width:11%;">
                    <i class="w3-xxlarge fa fa-user"></i>
                </div>
                <div class="w3-rest">
                    <input class="w3-input w3-border w3-round-large" name="txtNome" type="text" placeholder="Nome Completo" value="">
                </div>
            </div>
        </form>




        <!-- ------------------------------------------------ FORMAÇÃO -->
        <div class="w3-padding-128 w3-content w3-text-grey" id="formacao">
            <h2 class="w3-text-cyan">Formação</h2>
        </div>

        <form action="" method="post" class="w3-row w3-light-grey w3-text-blue w3-margin" style="width:70%;">

            <div class="w3-row w3-center">
                <div class="w3-col" style="width:50%;">Data Inicial</div>
                <div class="w3-rest">Data Final</div>
            </div>

            <div class="w3-row w3-section">
                <div class="w3-col" style="width:45%;">
                    <div class="w3-col" style="width:15%;">
                        <i class="w3-xxlarge fa fa-calendar"></i>
                    </div>
                    <div class="w3-rest">
                        <input class="w3-input w3-border w3-round-large" name="txtInicioFA" 
                        type="date" 
                        placeholder="">
                    </div>
                </div>

                <div class="w3-rest">
                    <div class="w3-col w3-margin-left" style="width:13%;">
                        <i class="w3-xxlarge fa fa-calendar"></i>
                    </div>
                    <div class="w3-rest">
                        <input class="w3-input w3-border w3-round-large" name="txtFimFA" 
                        type="date" 
                        placeholder="">
                    </div>
                </div>
            </div>

            <div class="w3-row w3-section">
                <div class="w3-col" style="width:7%;">
                    <i class="w3-xxlarge fa fa-align-justify"></i>
                </div>
                <div class="w3-rest">
                    <input class="w3-input w3-border w3-round-large" name="txtDescFA" 
                    type="text" 
                    placeholder="Graduado em Desenvolvimento de Sistemas">
                </div>
            </div>

            <div class="w3-row w3-section">
                <div class="w3-center" style="">
                    <button name="btnAddFormacao" 
                    class="w3-button w3-block w3-blue w3-cell w3-round-large" style="width:20%;">
                        <i class="fa fa-user-plus w3-xxlarge"></i>
                    </button>
                </div>
            </div>
        </form>

        <div class="w3-container">
            <table class="w3-table-all w3-centered">
                <thead>
                    <tr class="w3-blue">
                        <th>Início</th>
                        <th>Fim</th>
                        <th>Descrição</th>
                        <th>Apagar</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Linhas de formação serão preenchidas depois via PHP -->
                </tbody>
            </table>
        </div>



        <!----------------------------------- EXPERIÊNCIA PROFISSIONAL -->
        <div class="w3-padding-128 w3-content w3-text-grey" id="eProfissional">
            <h2 class="w3-text-cyan">Experiência Profissional</h2>
        </div>

        <form action="" method="post" class="w3-row w3-light-grey w3-text-blue w3-margin" style="width:70%;">

            <div class="w3-row w3-center">
                <div class="w3-col" style="width:50%;">Data Inicial</div>
                <div class="w3-rest">Data Final</div>
            </div>

            <div class="w3-row w3-section">
                <div class="w3-col" style="width:45%;">
                    <div class="w3-col" style="width:15%;">
                        <i class="w3-xxlarge fa fa-calendar"></i>
                    </div>
                    <div class="w3-rest">
                        <input class="w3-input w3-border w3-round-large" name="txtInicioEP" type="date">
                    </div>
                </div>

                <div class="w3-rest">
                    <div class="w3-col w3-margin-left" style="width:13%;">
                        <i class="w3-xxlarge fa fa-calendar"></i>
                    </div>
                    <div class="w3-rest">
                        <input class="w3-input w3-border w3-round-large" name="txtFimEP" type="date">
                    </div>
                </div>
            </div>

            <div class="w3-row w3-section">
                <div class="w3-col" style="width:7%;">
                    <i class="w3-xxlarge fa fa-building"></i>
                </div>
                <div class="w3-rest">
                    <input class="w3-input w3-border w3-round-large" name="txtEmpEP" type="text" placeholder="Etec">
                </div>
            </div>

            <div class="w3-row w3-section">
                <div class="w3-col" style="width:7%;">
                    <i class="w3-xxlarge fa fa-align-justify"></i>
                </div>
                <div class="w3-rest">
                    <input class="w3-input w3-border w3-round-large" name="txtDescEP" type="text" placeholder="Docente">
                </div>
            </div>

            <div class="w3-row w3-section">
                <div class="w3-center">
                    <button name="btnAddEP" class="w3-button w3-blue w3-round-large" style="width:20%;">
                        <i class="fa fa-user-plus w3-xxlarge"></i>
                    </button>
                </div>
            </div>
        </form>

        <div class="w3-container">
            <table class="w3-table-all w3-centered">
                <thead>
                    <tr class="w3-blue">
                        <th>Início</th>
                        <th>Fim</th>
                        <th>Empresa</th>
                        <th>Descrição</th>
                        <th>Apagar</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Linhas de experiência serão preenchidas depois via PHP -->
                </tbody>
            </table>
        </div>

        <!---------------------- OUTRAS FORMAÇÕES (ATIVIDADE AGENDA 12)-->
        <div class="w3-padding-128 w3-content w3-text-grey" id="oFormacoes">
            <h2 class="w3-text-cyan">Outras Formações (Cursos) </h2>
        </div>

        <form action="" method="post" class="w3-row w3-light-grey w3-text-blue w3-margin" style="width:70%;">

            <div class="w3-row w3-center">
                <div class="w3-col" style="width:50%;">Data Inicial</div>
                <div class="w3-rest">Data Final</div>
            </div>

            <div class="w3-row w3-section">
                <div class="w3-col" style="width:45%;">
                    <div class="w3-col" style="width:15%;">
                        <i class="w3-xxlarge fa fa-calendar"></i>
                    </div>
                    <div class="w3-rest">
                        <input class="w3-input w3-border w3-round-large" name="txtInicioOF" 
                        type="date">
                    </div>
                </div>

                <div class="w3-rest">
                    <div class="w3-col w3-margin-left" style="width:13%;">
                        <i class="w3-xxlarge fa fa-calendar"></i>
                    </div>
                    <div class="w3-rest">
                        <input class="w3-input w3-border w3-round-large"  name="txtFimOF" 
                        type="date">
                    </div>
                </div>
            </div>

            <div class="w3-row w3-section">
                <div class="w3-col" style="width:7%;">
                    <i class="w3-xxlarge fa fa-align-justify"></i>
                </div>
                <div class="w3-rest">
                    <input class="w3-input w3-border w3-round-large"    name="txtDescOF" 
                    type="text"
                           placeholder="Curso de HTML/CSS - Curso em Vídeo">
                </div>
            </div>

            <div class="w3-row w3-section">
                <div class="w3-center">
                    <button name="btnAddOF" 
                    class="w3-button w3-blue w3-round-large" style="width:20%;">
                        <i class="fa fa-plus w3-xxlarge"></i>
                    </button>
                </div>
            </div>
        </form>

        <div class="w3-container">
            <table class="w3-table-all w3-centered">
                <thead>
                    <tr class="w3-blue">
                        <th>Início</th>
                        <th>Fim</th>
                        <th>Descrição</th>
                        <th>Apagar</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Linhas de experiência serão preenchidas depois via PHP -->
                </tbody>
            </table>
        </div>


<?php
if(!isset($_SESSION)) {
    session_start();
}

require_once '../Model/Usuario.php';
require_once '../Model/FormacaoAcademica.php';
require_once '../Model/ExperienciaProfissional.php';

$idUsuario = isset($_POST['idUsuario']) ? $_POST['idUsuario'] : null;
if ($idUsuario == null) {
    echo "<h3>Erro: Nenhum usuário selecionado.</h3>";
    exit;
}

$usuario = new Usuario();
$usuario->carregarUsuarioPorID($idUsuario);

$formacao = new FormacaoAcad();
$listaFA = $formacao->listarPorUsuario($id);

$experiencia = new ExperienciaProfissional();
$listaEP = $experiencia->listarPorUsuario($id);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<title>Visualizar Cadastro</title>
</head>

<body class="w3-light-grey">

<header class="w3-container w3-center w3-padding-32">
    <h1 class="w3-panel w3-cyan w3-round-large w3-text-white">
        Dados do Usuário
    </h1>
</header>

<div class="w3-content w3-padding">

    <div class="w3-card w3-white w3-padding">
        <h2 class="w3-text-blue">Dados Pessoais</h2>
        <p><b>Nome:</b> <?= $usuario->getNome() ?></p>
        <p><b>CPF:</b> <?= $usuario->getCPF() ?></p>
        <p><b>Email:</b> <?= $usuario->getEmail() ?></p>
        <p><b>Data de Nascimento:</b> <?= $usuario->getDataNascimento() ?></p>
    </div>

    <br>

    <div class="w3-card w3-white w3-padding">
        <h2 class="w3-text-blue">Formação Acadêmica</h2>
        <?php
        if($listaFA != null) {
            while($fa = $listaFA->fetch_object()) {
                echo "<p><b>{$fa->descricao}</b> ({$fa->inicio} - {$fa->fim})</p>";
            }
        } else {
            echo "<p>Nenhuma formação cadastrada.</p>";
        }
        ?>
    </div>

    <br>

    <div class="w3-card w3-white w3-padding">
        <h2 class="w3-text-blue">Experiência Profissional</h2>
        <?php
        if($listaEP != null) {
            while($ep = $listaEP->fetch_object()) {
                echo "<p><b>{$ep->empresa}</b> ({$ep->inicio} - {$ep->fim})<br>{$ep->descricao}</p>";
            }
        } else {
            echo "<p>Nenhuma experiência cadastrada.</p>";
        }
        ?>
    </div>

    <br>

    <form action="/Controller/navegacao.php" method="post">
        <button name="btnListarCadastrados"
        class="w3-button w3-blue w3-round-large">Voltar</button>
    </form>

</div>

</body>
</html>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atividade 3 Action</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="style.css">
</head>

<body class="w3-monospace w3-light-grey custom-margin">

    <section class="w3-card w3-padding-48 w3-white w3-margin w3-round-large">
        <div class="w3-container w3-center">
            <h1 class="w3-left-align w3-border-top w3-border-bottom w3-text-grey">
                <!--
                Depósito == 10%
                Boleto == 8%
                -->
                <?php
                    $nomeCliente = $_POST['txtNome'];
                    $valorCompra = $_POST['txtValorCompra'];
                    $formaPagamento = $_POST['cmbPag'];
                    $valorPorcentagem;
                    if ($formaPagamento == 'deposito') {
                        $valorPorcentagem = 10;
                    } elseif ($formaPagamento == 'boleto') {
                        $valorPorcentagem = 8;
                    } else {
                        $valorPorcentagem = 0;
                    }
                    echo "PROMOÇÃO DE MÊS DE ANIVERSÁRIO!<br>";
                    echo "".$_POST['txtNome']."! <br>";
                    echo "Valor da compra Sem desconto: R$ ".$valorCompra."<br>";
                    echo "Forma de pagamento escolhida: ".$formaPagamento."<br>";
                    echo "Desconto de: ".$valorPorcentagem."% <br>";
                    echo "Você economizou: R$ ".$valorCompra*($valorPorcentagem/100)." <br>";
                    echo "Valor à Pagar: R$ ".$valorCompra - ($valorCompra*($valorPorcentagem/100))." <br>";
                ?>
                <!-- 
                Tentei fazer com que as estruturas condicionais abrangessem todas as possibilidades possíveis. Talvez eu pudesse reduzir o código em apenas uma estrutura if () {} else {}, mas entendo que nesse caso o valor exibido para porcentagem de desconto para a modalidade "Cartão de Crédito" não seir armazena, não podendo ser, portanto exibida;

                Desse modo decidi Trabalhar com estrutura condicioal composta :else if (){} else {};

                Alterei também a exibição (front-end) com o framework w3.css para praticar o uso da ferramenta;
                 -->
            </h1>
        </div>
    </section>

</body>

</html>
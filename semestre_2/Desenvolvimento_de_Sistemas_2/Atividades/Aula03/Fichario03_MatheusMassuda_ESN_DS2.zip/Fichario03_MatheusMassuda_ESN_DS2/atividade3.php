<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

    <link rel="stylesheet" href="style.css">

    <title>Atividade 3 Ds2</title>

</head>

<body class="w3-monospace custom-margin">

    <section class="w3-card w3-padding-48 w3-white custom-card">
        
            <div class="w3-container w3-padding-large">
                <div>
                    <h1 class="w3-border-bottom">Forma de pagamento</h1 class="w3-border-bottom">
                </div>
                
                <form class="w3-margin-top" method="post" action="atividade3Action.php">
                    <label class="w3-text-grey"><b>Nome do Cliente</b></label>
                    <input class="w3-input" name="txtNome" type="text">
                    <label class="w3-text-grey"><b>Valor  da Compra</b></label>
                    <input class="w3-input" name="txtValorCompra" type="number">
                    <label class="w3-text-grey"><b>Escolha a forma de Pagamento:</b></label>
                    <select class="w3-input"  name = "cmbPag">
                        <option value="cartaoCredito">Cartão de Crédito</option>
                        <option value="boleto">Boleto</option>
                        <option value="deposito" selected>Depósito</option>
                    </select>
                    <button class="w3-btn w3-dark-grey w3-margin-top">Enviar</button>
                </form>
            </div>
        
    </section>

</body>

</html>
<?php

$servername = "localhost";
$username = "pwii_user";
$password = "senha123";
$dbname = "pwii";
$conexao = new mysqli($servername, $username, $password, $dbname);
if ($conexao->connect_error) {
    die("Connection failed: " . $conexao->connect_error);
} 

?>


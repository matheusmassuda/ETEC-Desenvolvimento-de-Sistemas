<?php require_once ('cabecalho.php'); ?>
<div class="w3-padding w3-content w3-text-grey w3-third w3-display-middle">

    <?php
            echo '
            <a href="index.php">
                <h1 class="w3-button w3-teal">Acesso NEGADO! </h1>
                <br>
                <h2 class="w3-button w3-teal">É necessária a Realização do Login Inválido! </h2>
            </a> 
            ';
    ?>
</div>
<?php require_once ('rodape.php'); ?>